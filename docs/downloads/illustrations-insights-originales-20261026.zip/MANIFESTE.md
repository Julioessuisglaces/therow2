# Illustrations originales — collection Insights

Sources : illustrations déjà récupérées des articles originaux et présentes sur le site local. Aucun visuel généré ni substitué.

| No | Article | Fichier | Statut |
|---|---|---|---|
| 1 | Augmenter vos prix fait moins peur que de ne pas le faire | Aucun fichier source retrouvé | Absent de la version originale importée |
| 2 | Brand alignment : tenir sa promesse | brand-alignment-tenir-sa-promesse.avif | Inclus |
| 3 | Ce que coûte vraiment un oui | Aucun fichier source retrouvé | Absent de la version originale importée |
| 4 | Combien coûte l’incohérence de marque ? | cout-incoherence-marque.webp | Inclus |
| 5 | Pourquoi le patron ne peut pas diriger son marketing | directeur-marketing-pme-patron.webp | Inclus |
| 6 | Où faire (et ne pas faire) des économies en cas de crise ? | economies-en-cas-de-crise.webp | Inclus |
| 7 | Être présent partout, conseillent surtout ceux qui vendent les plateformes | Aucun fichier source retrouvé | Absent de la version originale importée |
| 8 | Pourquoi l’excellence technique ne protège plus vos marges et comment éviter la course vers le bas | guerre-des-prix-marges-pme-industrielle.webp | Inclus |
| 9 | Votre équipe marketing doit utiliser l’IA pour produire moins | ia-equipe-marketing-produire-moins.webp | Inclus |
| 10 | L’engagement social mesure votre marque comme les applaudissements mesurent vos ventes | Aucun fichier source retrouvé | Absent de la version originale importée |
| 11 | Les communautés acquièrent des clients comme les amis financent des entreprises | Aucun fichier source retrouvé | Absent de la version originale importée |
| 12 | Les données guident tout, sauf ce que votre marque doit devenir | Aucun fichier source retrouvé | Absent de la version originale importée |
| 13 | Les marques B2B négligent-elles TikTok ? | marques-b2b-tiktok.webp | Inclus |
| 14 | Nous servons toutes les industries, donc personne | Aucun fichier source retrouvé | Absent de la version originale importée |
| 15 | Rassurer un grand compte quand on reste une petite structure | petit-fournisseur-grand-compte-risque.png | Inclus |
| 16 | Votre proposition de valeur est jugée avant la première visite | proposition-valeur-pme-industrielle.webp | Inclus |
| 17 | Pourquoi tout le monde s’obstine à parler de qualité ? | qualite-positionnement-industrie.png | Inclus |
| 18 | Qualité suisse, ou l’art de ne rien dire | Aucun fichier source retrouvé | Absent de la version originale importée |
| 19 | Quand l’urgence commerciale remplace la stratégie | quand-lurgence-commerciale-remplace-la-strategie.avif | Inclus |
| 20 | Qui doit pouvoir décider pour la marque ? | qui-doit-decider-pour-la-marque.webp | Inclus |
| 21 | Le rabais n’est pas une erreur de vente | rabais-gouvernance-prix-industrie-suisse.avif | Inclus |
| 22 | Pourquoi notre croissance ralentit ? | ralentissement-croissance-pme.avif | Inclus |
| 23 | Tous les gros clients ne sont pas de bons clients | rentabilite-client-grands-comptes.webp | Inclus |
| 24 | Votre réputation s’arrête à la frontière | reputation-marque-pme-suisse.avif | Inclus |
| 25 | Comment revitaliser une marque vieillissante ? | revitaliser-marque-vieillissante.webp | Inclus |
| 26 | Le marketing doit-il vraiment prouver son ROI ? | roi-marketing-pme.png | Inclus |
| 27 | Quels produits garder, simplifier ou arrêter ? | simplifier-gamme-produits-complexe.png | Inclus |
| 28 | Vos délais de livraison s’écrivent le vendredi soir, au service commercial | Aucun fichier source retrouvé | Absent de la version originale importée |

## À compléter

- Augmenter vos prix fait moins peur que de ne pas le faire
- Ce que coûte vraiment un oui
- Être présent partout, conseillent surtout ceux qui vendent les plateformes
- L’engagement social mesure votre marque comme les applaudissements mesurent vos ventes
- Les communautés acquièrent des clients comme les amis financent des entreprises
- Les données guident tout, sauf ce que votre marque doit devenir
- Nous servons toutes les industries, donc personne
- Qualité suisse, ou l’art de ne rien dire
- Vos délais de livraison s’écrivent le vendredi soir, au service commercial